package com.example.Module1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Module1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
